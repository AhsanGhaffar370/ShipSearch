

<?php $__env->startSection('page_title','Post Listing'); ?>

<?php $__env->startSection('container'); ?>

<div class="">
    <div class="page-title">
        <div class="title_left">
            <h1>Cargo <span class="size16">Type</span></h1>
			<a href="/admin/cargo/view" class="btn btn-light border pt-2 pb-2 pl-3 pr-3">
				<i class="fas fa-eye"></i><br>
				<span class="size13">View All</span> 
			</a>
			<a href="/admin/cargo/add" class="btn btn-light border pt-2 pb-2 pl-3 pr-3">
				<i class="fas fa-plus"></i><br>
				<span class="size13">Add New</span> 
			</a>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">

        <div class="col-md-12 col-sm-12 ">
            <?php if(session('msg')!=""): ?>
            <div class="alert alert-<?php echo e(session('alert')); ?> alert-dismissible fade show text-center d-block" role="alert">
                <?php echo e(session('msg')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
            <div class="x_panel">
                <div class="x_content">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card-box ">
                                <table id="cargo_table" class="table table-striped table-responsive table-bordered" style="width:100%">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>#</th>
                                            <th>Unique Key</th>
                                            <th>Cargo Name</th>
                                            <th>Cargo Type</th>
                                            <th>Loading Region</th>
                                            <th>Loading Country</th>
                                            <th>Loading Port#1</th>
                                            <th>Loading Port#2</th>
                                            <th>Discharge Region</th>
                                            <th>Discharge Country</th>
                                            <th>Discharge Port#1</th>
                                            <th>Discharge Port#2</th>
                                            <th>Laycan Date From</th>
                                            <th>Laycan Date To</th>
                                            <th>Quantity</th>
                                            <th>Unit</th>
                                            <th>Max LOA</th>
                                            <th>Max Draft</th>
                                            <th>Max Height</th>
                                            <th>Commission</th>
                                            <th>Combinable</th>
                                            <th>Over Age</th>
                                            <th>Hazmat</th>
                                            <th>Loading Discharge Rates</th>
                                            <th>Loading Discharge Unit</th>
                                            <th>Loading Equipment Req</th>
                                            <th>Gear Lifting Capacity</th>
                                            <th>Loading/Discharge Equipment Req</th>
                                            <th>Additional Info</th>
                                            <th>Status</th>
                                            <!-- <th>Brocker Info</th> -->
                                            <th style="padding: 0px 30px 10px 30px;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($count++); ?></td>
                                            <td><?php echo e($row->cargo_id); ?></td>
                                            <td><?php echo e($row->cargo_name); ?></td>
                                            <td><?php echo e($row->cargo_type_name); ?></td>
                                            <td><?php echo e($row->R1name); ?></td>
                                            <td><?php echo e($row->C1name); ?></td>
                                            <td><?php echo e($row->P1name); ?></td>
                                            <td><?php echo e($row->P2name); ?></td>
                                            <td><?php echo e($row->DR1name); ?></td>
                                            <td><?php echo e($row->DC1name); ?></td>
                                            <td><?php echo e($row->DP1name); ?></td>
                                            <td><?php echo e($row->DP2name); ?></td>
                                            <td><?php echo e($row->laycan_date_from); ?></td>
                                            <td><?php echo e($row->laycan_date_to); ?></td>
                                            <td><?php echo e($row->quantity); ?></td>
                                            <td><?php echo e($row->U1unit); ?></td>
                                            <td><?php echo e($row->max_loa); ?></td>
                                            <td><?php echo e($row->max_draft); ?></td>
                                            <td><?php echo e($row->max_height); ?></td>
                                            <td><?php echo e($row->commision); ?></td>
                                            <td><?php echo e($row->combinable); ?></td>
                                            <td><?php echo e($row->over_age); ?></td>
                                            <td><?php echo e($row->hazmat); ?></td>
                                            <td><?php echo e($row->loading_discharge_rates); ?></td>
                                            <td><?php echo e($row->DU1unit); ?></td>
                                            <td><?php echo e($row->loading_equipment_req); ?></td>
                                            <td><?php echo e($row->gear_lifting_capacity); ?></td>
                                            <td><?php echo e($row->loading_discharge_equipment_req); ?></td>
                                            <td><?php echo e($row->additional_info); ?></td>
                                            <!-- <td>
												<strong>N:</strong><br>
												<strong>T:</strong><br>
												<strong>E:</strong>
											</td> -->
                                            
                                            <td>
                                                <?php if($row->is_active =="1"): ?>
                                                <span class="badge badge-success">Active</span>
                                                <?php else: ?>
                                                <span class="badge badge-danger">In-Active</span>
                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <div class="btn-group" style="display: -webkit-box;">
                                                    <a href='/admin/post/update-rec/<?php echo e($row->cargo_id); ?>'
                                                        class="btn btn-info btn-sm pt-1 pb-1">Edit</a>

                                                    <button type="button"
                                                        class="btn btn-info dropdown-toggle btn-sm pt-0 border-secondary border-left"
                                                        data-toggle="dropdown" aria-expanded="false"
                                                        style="padding-bottom: 1px !important">
                                                        <span class="caret"></span>
                                                        <span class="sr-only">Toggle Dropdown</span>
                                                    </button>
                                                    <ul class="dropdown-menu list-group" role="menu">
                                                        <?php if($row->is_active =="1"): ?>
                                                        <li><a href='/admin/post/update-status/<?php echo e($row->cargo_id); ?>/0'
                                                                class="list-group-item">De-Activate</a></li>
                                                        <?php else: ?>
                                                        <li><a href='/admin/post/update-status/<?php echo e($row->cargo_id); ?>/1'
                                                                class="list-group-item">Activate</a></li>
                                                        <?php endif; ?>
                                                    </ul>
                                                    <!-- <a href='/admin/post/delete-rec/<?php echo e($row->cargo_id); ?>'
                                                        class="btn btn-danger btn-sm ml-2 pt-1 pb-1 rounded">Delete</a> -->
                                                </div>
                                            </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shipsearch\resources\views/admin/cargo/list.blade.php ENDPATH**/ ?>