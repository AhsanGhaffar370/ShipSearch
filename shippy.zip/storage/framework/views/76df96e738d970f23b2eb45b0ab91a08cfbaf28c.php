

<?php $__env->startSection('page_title','Home Page'); ?>


<?php $__env->startSection('container'); ?>


<div class="container">
<h1>Home Page</h1>
<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sagittis augue non ex accumsan lobortis. Morbi a tortor aliquet, sollicitudin urna nec, fringilla lorem. Aliquam erat volutpat. Ut rutrum risus tellus. Proin gravida volutpat accumsan. Praesent ultricies finibus sodales. Mauris sed ex a neque tristique aliquam. Morbi dolor ipsum, ultricies ut fringilla sed, cursus eget urna.

Donec sagittis id magna vitae laoreet. Proin ut mi eu nisi aliquam lacinia in feugiat lacus. Mauris tempor ut arcu at bibendum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut eu hendrerit odio. Nunc ultrices velit tortor, at ultricies diam tincidunt et. Cras faucibus diam vel ex eleifend, in mollis ex consectetur. Mauris eget imperdiet velit, suscipit vehicula ante. In hac habitasse platea dictumst. Ut tempor tellus nibh, quis luctus purus molestie vel. Duis euismod mauris ac laoreet eleifend. Curabitur semper orci posuere ante aliquet, sit amet semper sem vestibulum. Sed consectetur odio eu leo ultrices, ac elementum lectus pretium. Cras sed sollicitudin nibh, quis molestie quam. Pellentesque id massa nec lorem dignissim varius id in turpis. Phasellus massa metus, eleifend bibendum fringilla ullamcorper, dictum molestie neque.

Quisque purus mauris, feugiat quis magna eleifend, rhoncus scelerisque augue. Cras volutpat nisi mauris, ac euismod urna consequat sit amet. Mauris vitae faucibus orci. Nullam laoreet placerat elit sed suscipit. Nulla nec viverra neque, et tristique orci. Suspendisse ac fringilla metus, et ullamcorper lacus. Quisque ac molestie magna. Nullam rhoncus pretium est, consectetur vulputate tellus eleifend nec.
</p>
<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sagittis augue non ex accumsan lobortis. Morbi a tortor aliquet, sollicitudin urna nec, fringilla lorem. Aliquam erat volutpat. Ut rutrum risus tellus. Proin gravida volutpat accumsan. Praesent ultricies finibus sodales. Mauris sed ex a neque tristique aliquam. Morbi dolor ipsum, ultricies ut fringilla sed, cursus eget urna.

Donec sagittis id magna vitae laoreet. Proin ut mi eu nisi aliquam lacinia in feugiat lacus. Mauris tempor ut arcu at bibendum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut eu hendrerit odio. Nunc ultrices velit tortor, at ultricies diam tincidunt et. Cras faucibus diam vel ex eleifend, in mollis ex consectetur. Mauris eget imperdiet velit, suscipit vehicula ante. In hac habitasse platea dictumst. Ut tempor tellus nibh, quis luctus purus molestie vel. Duis euismod mauris ac laoreet eleifend. Curabitur semper orci posuere ante aliquet, sit amet semper sem vestibulum. Sed consectetur odio eu leo ultrices, ac elementum lectus pretium. Cras sed sollicitudin nibh, quis molestie quam. Pellentesque id massa nec lorem dignissim varius id in turpis. Phasellus massa metus, eleifend bibendum fringilla ullamcorper, dictum molestie neque.

Quisque purus mauris, feugiat quis magna eleifend, rhoncus scelerisque augue. Cras volutpat nisi mauris, ac euismod urna consequat sit amet. Mauris vitae faucibus orci. Nullam laoreet placerat elit sed suscipit. Nulla nec viverra neque, et tristique orci. Suspendisse ac fringilla metus, et ullamcorper lacus. Quisque ac molestie magna. Nullam rhoncus pretium est, consectetur vulputate tellus eleifend nec.
</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\shipsearch\resources\views/front/home.blade.php ENDPATH**/ ?>