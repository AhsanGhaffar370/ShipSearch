@extends('admin/layout/layout')

@section('page_title','Post Listing')

@section('container')

<h1>Welcome {{session('user_name')}}</h1>
@endsection